# adashe smart contracts
